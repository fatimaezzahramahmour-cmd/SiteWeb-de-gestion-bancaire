package org.mybank.mybankmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybankmanagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(MybankmanagerApplication.class, args);
    }

}
